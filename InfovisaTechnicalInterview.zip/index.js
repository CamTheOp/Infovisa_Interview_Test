//Setting up builder to perform 
const {Builder, By, Key, util} = require("selenium-webdriver");

//Declaring variables
let timeAfterTest = 7000;
let testTimeout = 7000;
let email = "Ctyrellt@gmail.com";
let org = "Infovisa interview";
let phone = "8643810207";
let comments = "This is a test.";

//This is a negative test to see if form will submit without name *Passed*
async function negativeTesting1 () {
        let driver = await new Builder().forBrowser("chrome").build();
    try{
    await driver.get("https://www.infovisa.com/contact-us"); 
    await driver.findElement(By.name("submitted[email]")).sendKeys(email);
    await driver.findElement(By.name("submitted[company___organization]")).sendKeys(org);
    await driver.findElement(By.name("submitted[phone]")).sendKeys(phone);
    await driver.findElement(By.name("submitted[comments]")).sendKeys(comments, Key.TAB, Key.RETURN);
    }finally{
        setTimeout(async function() {
            await driver.quit();
        }, timeAfterTest);
    }
}


//This is a negative test to see if form will submit without email *Passed*
async function negativeTesting2 () {
        let driver = await new Builder().forBrowser("chrome").build();
    try{
    await driver.get("https://www.infovisa.com/contact-us"); 
    await driver.findElement(By.name("submitted[name]")).sendKeys("Bobby");
    await driver.findElement(By.name("submitted[company___organization]")).sendKeys(org);
    await driver.findElement(By.name("submitted[phone]")).sendKeys(phone);
    await driver.findElement(By.name("submitted[comments]")).sendKeys(comments, Key.TAB, Key.RETURN);
    }finally{
        setTimeout(async function() {
            await driver.quit();
        }, timeAfterTest);
    }
}

//This is a negative test to see if form will submit without correct email format *Passed*
async function negativeTesting3 () {
        let driver = await new Builder().forBrowser("chrome").build();
    try{
    await driver.get("https://www.infovisa.com/contact-us");
    await driver.findElement(By.name("submitted[name]")).sendKeys("Cameron"); 
    await driver.findElement(By.name("submitted[email]")).sendKeys("Ctyrellgmail.com");
    await driver.findElement(By.name("submitted[company___organization]")).sendKeys(org);
    await driver.findElement(By.name("submitted[phone]")).sendKeys(phone);
    await driver.findElement(By.name("submitted[comments]")).sendKeys(comments, Key.TAB, Key.RETURN);
    }finally{
        setTimeout(async function() {
            await driver.quit();
        }, timeAfterTest);
    }
}

//This is a negative test to see if form will submit without Company/Organization *Passed*
async function negativeTesting4 () {
        let driver = await new Builder().forBrowser("chrome").build();
    try{
    await driver.get("https://www.infovisa.com/contact-us");
    await driver.findElement(By.name("submitted[name]")).sendKeys("David"); 
    await driver.findElement(By.name("submitted[email]")).sendKeys(email);
    await driver.findElement(By.name("submitted[phone]")).sendKeys(phone);
    await driver.findElement(By.name("submitted[comments]")).sendKeys(comments, Key.TAB, Key.RETURN);
    }finally{
        setTimeout(async function() {
            await driver.quit();
        }, timeAfterTest);
    }
}


//This is a negative test to see if form will submit without numeric format for phone number *Passed*
async function negativeTesting5 () {
    let driver = await new Builder().forBrowser("chrome").build();
    try{
        await driver.get("https://www.infovisa.com/contact-us");
        await driver.findElement(By.name("submitted[name]")).sendKeys("Eric"); 
        await driver.findElement(By.name("submitted[email]")).sendKeys(email);
        await driver.findElement(By.name("submitted[company___organization]")).sendKeys(org);
        await driver.findElement(By.name("submitted[phone]")).sendKeys("864381020a");
        await driver.findElement(By.name("submitted[comments]")).sendKeys(comments, Key.TAB, Key.RETURN);
    }finally{
        setTimeout(async function() {
            await driver.quit();
        }, timeAfterTest);
    }
}

//This is a negative test to see if form will submit without correct number of digits for Domestic Phone Number **Failed**
async function negativeTesting6 () {
    let driver = await new Builder().forBrowser("chrome").build();
    try{
        await driver.get("https://www.infovisa.com/contact-us");
        await driver.findElement(By.name("submitted[name]")).sendKeys("Fred"); 
        await driver.findElement(By.name("submitted[email]")).sendKeys(email);
        await driver.findElement(By.name("submitted[company___organization]")).sendKeys(org);
        await driver.findElement(By.name("submitted[phone]")).sendKeys("86438102077777");
        await driver.findElement(By.name("submitted[comments]")).sendKeys(comments, Key.TAB, Key.RETURN);
    }finally{
        setTimeout(async function() {
            await driver.quit();
        }, timeAfterTest);
    }
}

//This is a negative test to see if form will submit without comments *Passed*
async function negativeTesting7 () {
    let driver = await new Builder().forBrowser("chrome").build();
    try{
        await driver.get("https://www.infovisa.com/contact-us");
        await driver.findElement(By.name("submitted[name]")).sendKeys("George"); 
        await driver.findElement(By.name("submitted[email]")).sendKeys(email);
        await driver.findElement(By.name("submitted[company___organization]")).sendKeys(org);
        await driver.findElement(By.name("submitted[phone]")).sendKeys(phone, Key.TAB, Key.TAB, Key.RETURN);
    }finally{
        setTimeout(async function() {
            await driver.quit();
        }, timeAfterTest);
    }
}

//This is a Positive test to see if form will submit with all fields correctly entered *Passed*
async function positiveTesting1 () {
    let driver = await new Builder().forBrowser("chrome").build();
    try{
        await driver.get("https://www.infovisa.com/contact-us");
        await driver.findElement(By.name("submitted[name]")).sendKeys("Harry"); 
        await driver.findElement(By.name("submitted[email]")).sendKeys(email);
        await driver.findElement(By.name("submitted[company___organization]")).sendKeys(org);
        await driver.findElement(By.name("submitted[phone]")).sendKeys(phone);
        await driver.findElement(By.name("submitted[comments]")).sendKeys(comments, Key.TAB, Key.RETURN);
    }finally{
        setTimeout(async function() {
            await driver.quit();
        }, timeAfterTest);
    }
}

//This is a Positive test to see if form will submit without Phone Number *Passed*
async function PositiveTesting2 () {
        let driver = await new Builder().forBrowser("chrome").build();
    try{
    await driver.get("https://www.infovisa.com/contact-us");
    await driver.findElement(By.name("submitted[name]")).sendKeys("Ivan"); 
    await driver.findElement(By.name("submitted[email]")).sendKeys(email);
    await driver.findElement(By.name("submitted[company___organization]")).sendKeys(org);
    await driver.findElement(By.name("submitted[comments]")).sendKeys(comments, Key.TAB, Key.RETURN);
    }finally{
        setTimeout(async function() {
            await driver.quit();
        }, timeAfterTest);
    }
}


negativeTesting1();//*Passed*
const testOneTimeout = setTimeout (negativeTesting2,testTimeout*2);//*Passed*
const testTwoTimeout = setTimeout (negativeTesting3,testTimeout*3);//*Passed*
const testThreeTimeout = setTimeout (negativeTesting4,testTimeout*4);//*Passed*
const testFiveTimeout = setTimeout (negativeTesting5,testTimeout*5);//*Passed*
const testSixTimeout = setTimeout (negativeTesting6,testTimeout*6);//**Failed**
const testSevenTimeout = setTimeout (negativeTesting7,testTimeout*7);//*Passed*
const testEightTimeout = setTimeout (positiveTesting1,testTimeout*8);//*Passed*
const testFourTimeout = setTimeout (PositiveTesting2,testTimeout*9);//*Passed*